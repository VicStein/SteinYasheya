import React from 'react'
import Contact from './Contact'

const GeneralInquiry = () => {
  return (
    <Contact />
  )
}

export default GeneralInquiry
